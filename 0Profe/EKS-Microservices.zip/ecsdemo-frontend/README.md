# THIS REPOSITORY IS DEPRECATED

Please go here for any updates and/or changes: https://github.com/aws-containers/ecsdemo-frontend
